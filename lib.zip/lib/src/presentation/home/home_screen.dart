import 'package:_iwu_pack/setup/app_setup.dart';
import 'package:flutter/material.dart';
import 'package:meta_business/src/presentation/home/widget/header.dart';

import 'widget/content.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColorBackground,
      body: const SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //header
            Header(),
            //body
            Content()
            // ContentSide(context)
          ],
        ),
      ),
    );
  }
}
